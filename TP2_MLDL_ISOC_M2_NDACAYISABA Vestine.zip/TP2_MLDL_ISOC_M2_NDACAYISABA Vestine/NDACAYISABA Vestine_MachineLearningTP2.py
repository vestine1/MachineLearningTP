#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().run_line_magic('matplotlib', 'inline')


# # Travail Pratique 2 - Modèle de Prediction de la qualite d'un vin
# 
# L'objectif est de modéliser la qualité d'un vin sur la base des resultats de tests physico-chimiques. Pour cela nous allons utiliser 2 approches, une par la méthode de regression lineaire et l'autre par la méthode classification
# 
# Dans ce TP, nous allons apprendre comment:
# 
# - Extraire les données à partir d'un datahub distant
# 
# - Explorer des données pour des correlation eventuelles 
# 
# - Créer d'un modèle de regression linéaire
# 
# - Evaluer les métriques de regression
# 
# - Créer d'un modèle de classification 
# 
# - Utiliser le modèle pour des prédictions sur des nouvelles données
# 
# - Evaluer les métriques de classification
# 

# In[ ]:





# ### Description des données
# 
# Les données inclus un échantillon de vin rouge du nord du Portugal et publiees dans le repertoire de données de l'University of California, Irvine. 
# 
# Attributs ou variables d'entree (resultats de tests physico-chimiques):
# - fixed acidity
# - volatile acidity
# - citric acid
# - residual sugar
# - chlorides
# - free sulfur dioxide
# - total sulfur dioxide
# - density
# - pH
# - sulphates
# - alcohol
# - quality (varie de 0 a 10)
# 
# L'attribut "quality" est la cible que l'on veut predire
# 
# Pour avoir plus d'informations sur les données, visiter https://archive.ics.uci.edu/ml/datasets/Wine+Quality

# In[2]:


# Importer les librairies neccessaires pour la traitement et l'exploration des données
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# ### Extraire les données
# 
# Extraire les données à partir d'un datahub distant https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv
# 
# La méthode pandas read_csv() est decrite a l'adresse https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html
# 
# Faites attention au type de separateur utilisé.

# In[3]:


# Completer le code ci-dessous
##url = '............'
##df = pd.read_csv("C:/Users/HP/Documents/LES COURS DE M2 ISOC/SEMESTRE LMD 9 (S1)/Cours Machine Learning, Deep Learning et IA/TP2_MLDL_ISOC_M2_NDACAYISABA Vestine/winequality-red.csv", sep=';')
##df.head()

url = "C:/Users/HP/Documents/LES COURS DE M2 ISOC/SEMESTRE LMD 9 (S1)/Cours Machine Learning, Deep Learning et IA/TP2_MLDL_ISOC_M2_NDACAYISABA Vestine/winequality-red.csv"
df = pd.read_csv(url, sep=';')
df.head()


# In[4]:


# Affichez le nombre d'instances de vins et le nombre d'attributs
# https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.shape.html
dimension = df.shape
print("Nombre de lignes", dimension[0])
print("Nombre d'attributs", dimension[1])


# # Exploration des données pour detecter des tendances

# In[5]:


df.describe()


# In[6]:


df.columns.values


# In[7]:


df.describe()


# 
# 
# ### À partir de la description des données ci-dessus, que pensez-vous déjà de l'importance de l'attribut 'density' pour prédire la qualité du vin ? Faut-il la supprimer ou garder ? Ajouter votre commentaire ici
# 
# ......
# 

# In[8]:


# Pour l'instant nous n'allons pas supprimer l'attribut 'density'
# Verifiez s'il y a des colonnes avec des valeurs manquantes dans le tableau des données
# La fonction suivante compte le nombre de valeur manquantes par colonne
df.isnull().sum()


# In[9]:


# Verifiez s'il y a des valeurs anormales (outliers en anlgais) dans le tableau des données avec la fonction boxplot
# Pour l'instant nous n'allons pas les supprimer 
fig, ax = plt.subplots(ncols=4, nrows=3, figsize=(15, 5))
ax = ax.flatten()
index = 0
for column in df.columns:
  if column != 'quality':
    sns.boxplot(y=column, data=df, ax=ax[index])
    index +=1
plt.tight_layout(pad=0.4)
plt.show()


# ### Exploration des données pour detecter des tendances

# In[10]:


# completez le code ci-dessous
correlation = df.corr()
print("Tableau du degré de correlation entre les differents attributs")
correlation


# In[11]:


# On peut obtenir une meilleur visualisation avec la librairie seaborn
fig = plt.subplots(figsize=(10,10))
print("Tableau du degré de correlation entre les differents attributs avec seaborn")
sns.heatmap(correlation,vmax=1,square=True,annot=True,cmap='Reds')


# In[12]:


# Selectionnez les données d'entrées X (les 10 premières colonnes) et les données cibles Y (la dernière colone)
# Description du selecteur DataFrame.iloc https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.iloc.html


# In[13]:


X = df.iloc[:,:-1].values
Y = df.iloc[:,-1:].values


# In[14]:


# Pour chacun des attributs, affichez les diagrammes de Y en fonction de cet attribut
attributs = df.columns.values
for attribut in attributs:
    sns.set()
    sns.relplot(data=df,x=df[attribut],y='quality', kind='line',height=7,aspect=1)
    


# Y'en a-t-il parmi les 11 courbes qui presentent un certain degre de correlation (negative ou positive) avec la variable cible Y(qualite) ? Lesquelles ? 
# 
# Double-cliquez sur ce texte pour editer votre reponse et appuyer sur le bouton "Run".
# 

# ### Creation du modèle

# In[15]:


# Importez les librairies neccessaires pour l'entrainement du modèle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error


# In[16]:


# Completer les lignes de code ci-dessous (...)
# Scindez les donnes en 2 ensembles, dont 80% pour l'entrainement et 20% pour le test
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=100, random_state=4)

# Selectionnez l'algorithme LinearRegression
lr = LinearRegression()

# Learn the digits on the train subset
lr.fit(X_train, y_train)

# Predict the value of the digit on the test subset
y_pred = lr.predict(X_test)
# print(y_pred)


# In[17]:


# Affichez les coefficients W du modele
# Rappel de l'equation d'un modele de Regression lineaire: f(x) = w0 + w1*x1 + w2*x2 + ... + w11*x11
print("Valeurs des coefficients [w1,w2,...,w11]", lr.coef_)
print("Valeur de w0", lr.intercept_)


# # Evaluer les métriques de regression

# In[18]:


# Calculez l'exactitude du modele en utilisant le sous ensemble de test
# https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
accuracy = lr.score(X_test, y_test)
print(accuracy)


# In[19]:


# Calculez la moyenne quadratique entre les valeurs réelles du sous ensemble de test et les predictions de notre modele 
# https://scikit-learn.org/stable/modules/generated/sklearn.metrics.mean_squared_error.html
rmse_linear = mean_squared_error(y_test,y_pred)
print(rmse_linear)


# 
# # Créer un modèle de classification
# 
# ### Pour cela, vous devez remplacer ou convertir la colonne 'quality' en une variable binaire qui peut prendre 2 valeurs seulement: 0 si le vin est de mauvaise qualité (i.e qualité actuelle entre 0 et 5) ou 1 si le vin est de bonne qualité (i.e qualité actuelle entre 6 et 10)
# 

# In[20]:


# Create Classification version of target variable
df['goodquality'] = [1 if x >= 7 else 0 for x in df['quality']]
# Separate feature variables and target variable
X = df.drop(['quality','goodquality'], axis = 1)
y = df['goodquality']


# In[21]:


# Calculer et affichez les proportions de vins de bonne et de mauvaise qualité avec la fonction value_counts()
# https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.value_counts.html
# See proportion of good vs bad wines
df['goodquality'].value_counts()


# In[22]:


# Selectionnez les vins de bonne qualité
# Completez le code ci-dessous
#df_bonne_q = df[...==1]
#df_bonne_q.describe()
df_bonne_q = df[df['goodquality']==1]
df_bonne_q.describe()


# In[23]:


# Selectionnez les vins de mauvaise qualité
# Completez le code ci-dessous
# df_mauvaise_q = ...
# df_mauvaise_q.describe()
df_mauvaise_q = df[df['goodquality']==0]
df_mauvaise_q.describe()


# ### Normalisez les attributs: imaginez ensemble de données avec deux attributs, la taille en millimètres et le poids en kilogrammes, alors les valeurs numériques de la taille seront beaucoup plus élevées que celle du poids. Étant donné que l'algorithme de 'machine learning' n'utilise que les valeurs sans considerer leur unité de mesure, une plus grande importance sera automatiquement accordée à la taille qu'au poids, créant ainsi un biais.

# In[24]:


from sklearn.preprocessing import StandardScaler
X_attributs = X
X = StandardScaler().fit_transform(X)


# In[25]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
# Selectionnez l'algorithme de classification LogisticRegression

logist =LogisticRegression()
# Entrainez le modele
logist.fit(X_train, y_train)
# Prediction de la qualite de l'ensemble de test
y_pred_logist = logist.predict(X_test)
print(classification_report(y_test, y_pred_logist))


# In[26]:


from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report

# Selectionnez l'algorithme de classification DecisionTreeClassifier
logist = DecisionTreeClassifier(random_state=1)
# Entrainez le modele
logist.fit(X_train, y_train)
# Prediction de la qualite de l'ensemble de test
y_pred_logist = logist.predict(X_test)
print(classification_report(y_test, y_pred_logist))


# In[27]:


# Affichez les attributs qui ont plus d'influence sur la qualité du vin selon DecisionTreeClassifier
attributs_importances = pd.Series(logist.feature_importances_, index=X_attributs.columns)
attributs_importances.nlargest(25).plot(kind='barh',figsize=(10,10))


# 
# # Créer d'autres modèles de classification
# 
# ### Nous allons entrainer deux autres modeles en utilisant des algorithmes de types differents pour comparer leur performance
# 

# In[28]:


from sklearn.tree import DecisionTreeClassifier
# Selectionnez l'algorithme de classification DecisionTreeClassifier
dtree = DecisionTreeClassifier(random_state=1)

# Entrainez le modele
dtree.fit(X_train, y_train)

# Prediction de la qualite de l'ensemble de test
y_pred_dtree = dtree.predict(X_test)
print(classification_report(y_test, y_pred_dtree))


# In[29]:


# Affichez les attributs qui ont plus d'influence sur la qualité du vin selon DecisionTreeClassifier
attributs_importances = pd.Series(dtree.feature_importances_, index=X_attributs.columns)
attributs_importances.nlargest(25).plot(kind='barh',figsize=(10,10))


# In[30]:


from sklearn.ensemble import RandomForestClassifier
# Selectionnez l'algorithme de classification RandomForestClassifier
rforest = RandomForestClassifier(random_state=1)
rforest.fit(X_train, y_train)
y_pred_rforest = rforest.predict(X_test)
print(classification_report(y_test, y_pred_rforest))


# In[31]:


attributs_importances = pd.Series(rforest.feature_importances_, index=X_attributs.columns)
attributs_importances.nlargest(25).plot(kind='barh',figsize=(10,10))


# In[ ]:




