#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
print(np.__version__)


# ### Importer la librairie Pandas puis Afficher sa version

# # Tableau Numpy

# ### Creer un tableau numpy 1D

# In[2]:


my_array = np.array([1, 2, 3, 4, 5])
my_array


# In[3]:


# Calculer la taille du tableau avec la function len() et affichez
tailleArray = len(my_array)
tailleArray


# In[4]:


# Selection une portion du tableau du [2:4]
my_array[2:4]


# #### Calculer la moyenne des éléments du tableau de 2 facons:
# #### 1) en appelant la méthode .mean sur l'objet tableau numpy, my_array, 
# #### 2) en appliquant la fonction np.mean avec le tableau numpy en argument.

# In[5]:


import numpy

my_array = numpy.array([1, 2, 3, 4, 5])

x = numpy.mean(my_array)

print(x) 


# In[6]:


import numpy as np

my_array = np.array([1, 2, 3, 4, 5])

x = np.mean(my_array)

print(x) 


# #### Creez un tableau 2D

# In[7]:


tab_a = np.array([[1, 2, 3], [4, 5, 6]])
print(tab_a)


# #### Calculer les dimensions du tableau tab_a a l'aide de la fonction numpy.shape()

# In[8]:


import numpy
tab_a = numpy.array([[1, 2, 3], [4, 5, 6]])
numpy.shape(tab_a)


# #### Utilisez la fonction np.dot() pour calculer le produit matriciel de a et b

# In[9]:


a = np.array([[1, 2, 3], [4, 5, 6]])
b = np.array([[4], [2], [1]])
np.dot(a,b)


# #### Creer un tableau 2D

# In[10]:


a = np.array([[1, 2, 3], [4, 5, 6]])
print(a)


# #### Selectionner dans ce tableau l'element a la rangee 0 et colonne 1

# In[11]:


a = np.array([[1, 2, 3], [4, 5, 6]])
a[0,1]


# #### Selectionner sur toutes les rangees les elements de la colonne 1 a 2

# In[12]:


a = np.array([[1, 2, 3], [4, 5, 6]])
a[:,1:3]


# #### Selectionner sur toutes les rangees les elements de la colonne 1 seulement

# In[13]:


a = np.array([[1, 2, 3], [4, 5, 6]])
a[:,1]


# #### Selectionner sur toutes les colonnnes les elements de la rangee 1 seulement

# In[14]:


a = np.array([[1, 2, 3], [4, 5, 6]])
a[0,:]


# In[15]:


#  toutes les colonnnes les elements de la rangée 2 seulement
a = np.array([[1, 2, 3], [4, 5, 6]])
a[1,:]


# #### Calculer et afficher la somme des deux tableau a et b

# In[16]:


a = np.array([0, 1, 2])
b = np.array([5, 5, 5])
np.sum(a+b)


# #### Calculer et afficher la somme du tableau a et de l'entier 5

# In[17]:


a = np.array([0, 1, 2])
np.sum(a+5)


# 
# # Traitement des donnees(Data Munging) avec Pandas
# 
# #### Lire le fichier de données Employees.csv a l'aide de la function pd.read_csv() puis afficher les 5 premieres rangées Le notebook et le fichier de données se trouvent dans le meme repertoire. Notez que pour lire un fichier d'un repertoire different, il faudrait indiquer le chemin relatif ou absolu
# 

# In[18]:


import numpy as np
import pandas as pd
###import csv
df= pd.read_csv("C:/Users/HP/Documents/LES COURS DE M2 ISOC/SEMESTRE LMD 9 (S1)/Cours Machine Learning, Deep Learning et IA/ml_udschang-main/ml_udschang-main/Employees.csv")


# In[19]:


print(df)


# In[20]:


df.head()


# In[21]:


#imprimer la liste des colonnes
print(df.columns)


# #### Renommer la troisieme colonne de la dataframe pour 'Final Weight' puis afficher de nouveau la liste des colonnes pour observer le changement

# In[22]:


#df.rename(columns={df.columns[...]:'...'}, inplace=True)

df.rename(columns={'fnlwgt':'Final Weight'}, inplace=True)


# In[23]:


print(df.columns)


# In[24]:


df.head()


# #### Afficher les valeurs unique des 2 attributs Final Weight et occupation

# In[25]:


#print('age\t', df.age.unique())

print('age\t', df.age.unique())
print('occupation\t', df.occupation.unique())


# In[26]:


#print('Final Weight\t',df.Final Weight.unique())
print('Final Weight\t',df['Final Weight'].unique())
print('occupation\t', df.occupation.unique())


# #### Selectionnez la colonne 'occupation' et affichez les 5 premiers elements

# In[27]:


df.occupation.head()


# In[28]:


#### Une 2e facon de selectionner la colonne 'occupation' et affichez les 5 premiers elements


# In[29]:


print(df['occupation'].head())


# #### Une 3e facon de selectionner la colonne 'occupation' et affichez les 5 premiers elements

# In[30]:


print(df[['occupation']].head())


# #### Notez bien la difference dans la syntax et imprimez le type des trois results. Dans le premier exemple, nous utilisons une liste de colonnes (une colonne dans ce cas) et on obtient une DataFrame. Dans les second et troisieme examples on utlise le nom d'une colonne et on obtient une Series

# In[31]:


print("type of df['occupation']:\t", type(df['occupation']))
print("type of df.occupation:\t", type(df.occupation))
print("type of df[['occupation']]:\t", type(df[['occupation']]))


# #### En une seule ligne, selectionnez une portion de la dataframe en utilisant une liste des quatre colonnes 'age', 'occupation', 'permanent', 'hourly-salary' et affichez les 10 dernieres rangees avec la method tail().

# In[32]:


# avec tous les colonnes
df.tail(10)


# In[33]:


# avec les colonne: 'age', 'occupation', 'permanent', 'hourly-salary'
df[['age','occupation','permanent','hourly-salary']].tail(10)


# #### La fonction groupby de pandas: ici, on veut regrouper les instances(rangees) de la dataframe par rapport a la valeur de une ou quelques attributs.

# In[34]:


groupby_occupation = df.groupby('occupation')
print(type(groupby_occupation))
groupby_occupation.head()


# #### La fonction groupby vous donne un objet de type dictionnaire, les clés étant les valeurs du facteur et les valeurs étant les sous-ensembles de la dataframe correspondants au facteur.

# In[35]:


for key, value in groupby_occupation:
    print("( key, type(value) ) = (", key, ",", type(value), ")")
    v=value

v.head()


# #### Utilisez la methode describe() pour afficher plus d'information sur l'objet de type dictionnaire groupby_occupation

# In[36]:


groupby_occupation = df.groupby('occupation')
groupby_occupation.describe()


# #### Utilisez la fonction groupby de pandas pour regrouper les instances(rangees) de la dataframe par rapport a la valeur d'une liste de deux attributs 'age' et 'occupation' puis afficher les 5 premieres rangees du resultat.

# In[37]:


import numpy as np
import pandas as pd
df= pd.read_csv("C:/Users/HP/Documents/LES COURS DE M2 ISOC/SEMESTRE LMD 9 (S1)/Cours Machine Learning, Deep Learning et IA/ml_udschang-main/ml_udschang-main/Employees.csv")

groupby_age_occupation = df.groupby(['age','occupation'])
groupby_age_occupation.head()


# #### Afficher les clés et les valeurs (types des sous-ensembles) de la dataframe correspondants a la clé.

# In[38]:


for key, value in groupby_age_occupation:
    print("( key, type(value) ) = (", key, ",", type(value), ")")
    v=value

v.head()


# #### 
# 
# Creer une nouvelle dataframe dfsub comprenant seulement la liste d'attributs et en utilisant la fonction apply de pandas pour diviser toutes les valeurs par 100.
# 
# Pour plus d'informations sur la fonction apply de pandas, un Google search avec pour cle 'python pandas dataframe apply' vous renvoie la documentation, https://pandas.pydata.org/pandas-docs/dev/generated/pandas.DataFrame.apply.html
# 

# In[39]:


adultlist = ['age', 'education-num', 'capital-gain', 'capital-loss', 'hours-per-week', 'number-years', 'hourly-salary']
dfsub=df[adultlist].apply(lambda x: x/100.0)
dfsub.head()


# In[ ]:




